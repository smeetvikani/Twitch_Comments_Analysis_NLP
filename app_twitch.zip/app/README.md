# VIDEO PREDICTOR #

VIDEO predictor attempts to get data from a video and predict future frames.
